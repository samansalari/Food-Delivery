import AdminDashboard from "@/components/admin/dashboard"

export default function AdminDashboardPage() {
  return <AdminDashboard />
}

