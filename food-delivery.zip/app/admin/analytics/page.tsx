import AnalyticsDashboard from "@/components/admin/analytics"

export default function AnalyticsPage() {
  return <AnalyticsDashboard />
}

