import OrdersDashboard from "@/components/admin/orders"

export default function OrdersPage() {
  return <OrdersDashboard />
}

