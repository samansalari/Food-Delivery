import FinanceDashboard from "@/components/admin/finance"

export default function FinancePage() {
  return <FinanceDashboard />
}

