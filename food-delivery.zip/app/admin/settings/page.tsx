import SettingsDashboard from "@/components/admin/settings"

export default function SettingsPage() {
  return <SettingsDashboard />
}

