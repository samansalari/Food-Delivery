import AdminLoginPage from "@/components/admin/login-page"

export default function AdminLoginRoute() {
  return <AdminLoginPage />
}

