import UserManagement from "@/components/admin/user-management"

export default function UserManagementPage() {
  return <UserManagement />
}

