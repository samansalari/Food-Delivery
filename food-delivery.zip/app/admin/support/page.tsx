import SupportDashboard from "@/components/admin/support"

export default function SupportPage() {
  return <SupportDashboard />
}

